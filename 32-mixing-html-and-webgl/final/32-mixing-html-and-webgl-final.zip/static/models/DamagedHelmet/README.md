# Damaged Helmet

## Screenshot

![screenshot](screenshot/screenshot.png)

## License Information

Battle Damaged Sci-fi Helmet - PBR by [theblueturtle_](https://sketchfab.com/theblueturtle_), published under a Creative Commons Attribution-NonCommercial license

https://sketchfab.com/models/b81008d513954189a063ff901f7abfe4

## Modifications

The original model was built on an early draft of glTF 2.0 that did not become final.  This new model has been imported and re-exported from Blender to bring it into alignment with the final release glTF 2.0 specification.
